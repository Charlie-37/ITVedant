from django import forms
from .models import Emp,EmpQuali

class EmpForm(forms.ModelForm):
    class Meta:
        model=Emp
        fields="__all__"

class EmpQualiForm(forms.ModelForm):
    class Meta:
        model=EmpQuali
        fields="__all__"