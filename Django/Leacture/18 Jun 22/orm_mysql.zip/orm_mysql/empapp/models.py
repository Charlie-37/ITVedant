from django.db import models

class Emp(models.Model):
    name=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    address=models.TextField(max_length=300)

    def __str__(self):
        return self.name
        
class EmpQuali(models.Model):
    college=models.CharField(max_length=30)
    hsc=models.IntegerField()
    ssc=models.IntegerField()
    grad=models.IntegerField()
    description=models.TextField(max_length=400)
    emp=models.ForeignKey(Emp,on_delete=models.CASCADE)

    class Meta:
        db_table="emp_qualif"