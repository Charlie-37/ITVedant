
from django.contrib import admin
from django.urls import path
from .import views as v
urlpatterns = [
    path("",v.home),
    path("empr",v.addemp),
    path("empq",v.add_qualif),
    path("eqlist",v.emp_qualif_list),
]
